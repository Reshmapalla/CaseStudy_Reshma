﻿using JeansAppAPI.Entities;
using JeansAppAPI.Models;
using JeansAppAPI.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace JeansAppAPI.Controllers
{
    [Route("api/[Controller]")]
    [ApiController]
    public class AuthenticateController : ControllerBase
    {
        private readonly IUserRepository _userRepository;

        // Constructor to inject the IUserRepository dependency
        public AuthenticateController(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        // GET: api/Authenticate/GetAllUsers
        // Asynchronously retrieves all users
        [HttpGet, Route("GetAllUsers")]
        public async Task<IActionResult> GetAllUsers()
        {
            try
            {
                // Call the repository to fetch all users asynchronously
                var users = await _userRepository.GetAllUsersAsync();

                // Return the users with status 200 OK
                return Ok(users);
            }
            catch (Exception ex)
            {
                // Log the exception and return a 500 Internal Server Error
                Console.WriteLine($"An error occurred while fetching users: {ex.Message}");
                return StatusCode(500, "Internal server error");
            }
        }

        // POST: api/Authenticate/Registration
        // Asynchronously registers a new user
        [HttpPost, Route("Registration")]
        public async Task<IActionResult> Add([FromBody] User user)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    // Call the repository to register the user asynchronously
                    await _userRepository.RegisterAsync(user);

                    // Return the registered user with status 200 OK
                    return StatusCode(200, user);
                }
                catch (Exception ex)
                {
                    // Log the exception and return a 500 Internal Server Error
                    Console.WriteLine($"An error occurred while registering the user: {ex.Message}");
                    return StatusCode(500, "Internal server error");
                }
            }
            else
            {
                // Return a 400 Bad Request if the model state is invalid
                return BadRequest("Enter valid details");
            }
        }

        // POST: api/Authenticate/Validate
        // Asynchronously validates a user by email and password
        [HttpPost, Route("Validate")]
        public async Task<IActionResult> ValidUser([FromBody] Login login)
        {
            try
            {
                AuthResponse authResponse = null;

                // Call the repository to validate the user asynchronously
                var user = await _userRepository.ValidUserAsync(login.Email, login.Password);

                if (user != null)
                {
                    // Create an AuthResponse object if the user is valid
                    authResponse = new AuthResponse
                    {
                        UserId = user.UserId,
                        Role = user.Role,
                        UserName = user.Name,
                        Mobile = user.Mobile
                    };
                }

                // Return the AuthResponse with status 200 OK
                return Ok(authResponse);
            }
            catch (Exception ex)
            {
                // Log the exception and return a 500 Internal Server Error
                Console.WriteLine($"An error occurred during user validation: {ex.Message}");
                return StatusCode(500, "Internal server error");
            }
        }

        // DELETE: api/Authenticate/DeleteUser
        // Asynchronously deletes a user by ID
        [HttpDelete, Route("DeleteUser")]
        public async Task<IActionResult> Delete([FromQuery] string id)
        {
            try
            {
                // Call the repository to delete the user asynchronously
                await _userRepository.DeleteAsync(id);

                // Return the deleted user ID with status 200 OK
                return Ok(id);
            }
            catch (Exception ex)
            {
                // Log the exception and return a 500 Internal Server Error
                Console.WriteLine($"An error occurred while deleting the user: {ex.Message}");
                return StatusCode(500, "Internal server error");
            }
        }

        // PUT: api/Authenticate/EditUser
        // Asynchronously updates an existing user
        [HttpPut, Route("EditUser")]
        public async Task<IActionResult> Update([FromBody] User user)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    // Call the repository to update the user asynchronously
                    await _userRepository.UpdateAsync(user);

                    // Return the updated user with status 200 OK
                    return StatusCode(200, user);
                }
                catch (Exception ex)
                {
                    // Log the exception and return a 500 Internal Server Error
                    Console.WriteLine($"An error occurred while updating the user: {ex.Message}");
                    return StatusCode(500, "Internal server error");
                }
            }
            else
            {
                // Return a 400 Bad Request if the model state is invalid
                return BadRequest("Enter valid details");
            }
        }
    }
}
