﻿//using JeansAppAPI.Entities;
//using JeansAppAPI.Repository;
//using Microsoft.AspNetCore.Mvc;

//namespace JeansAppAPI.Controllers
//{
//    [Route("api/[Controller]")]
//    [ApiController]
//    public class OrderController : Controller
//    {
//        private readonly IOrderRepository _repository;

//        public OrderController(IOrderRepository repository)
//        {
//            _repository = repository;
//        }

//        [HttpGet, Route("GetAllOrders")]
//        public IActionResult GetAll()
//        {
//            var orders = _repository.GetAllOrders();
//            return StatusCode(200, orders);
//        }

//        [HttpGet, Route("GetOrderById/{id}")]
//        public IActionResult GetOrderById([FromRoute] Guid id)
//        {
//            var order = _repository.GetOrderById(id);
//            if (order != null)
//            {
//                return StatusCode(200, order);
//            }
//            else
//                return StatusCode(404, "Invalid Id");

//        }
//        [HttpPost, Route("AddOrder")]
//        public IActionResult Add([FromBody] Order order)
//        {
//            if (ModelState.IsValid)
//            {
//                order.OrderId = Guid.NewGuid();  // Generate OrderId
//                _repository.Add(order);
//                return StatusCode(200, order);
//            }
//            else
//                return BadRequest("enter valid details");

//        }
//        [HttpDelete, Route("Delete Order")]
//        public IActionResult Delete(Guid id)
//        {

//            _repository.Delete(id);
//            return Ok(id);
//        }
//    }
//}
