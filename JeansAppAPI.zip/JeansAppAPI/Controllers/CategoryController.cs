﻿using JeansAppAPI.Entities;
using JeansAppAPI.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace JeansAppAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        private readonly ICategoryRepository _categoryRepository;

        public CategoryController(ICategoryRepository categoryRepository)
        {
            _categoryRepository = categoryRepository ?? throw new ArgumentNullException(nameof(categoryRepository));
        }

        /// <summary>
        /// Retrieves all categories.
        /// </summary>
        /// <returns>An IActionResult containing the list of categories.</returns>
        [HttpGet("GetAllCategories")]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var categories = await _categoryRepository.GetAllCategories();
                return Ok(categories);
            }
            catch (Exception ex)
            {
                // Log the exception (logging not implemented here)
                return StatusCode(500, "An error occurred while retrieving categories.");
            }
        }

        /// <summary>
        /// Retrieves a category by its ID.
        /// </summary>
        /// <param name="id">The ID of the category to retrieve.</param>
        /// <returns>An IActionResult containing the category if found, or a not found status if not found.</returns>
        [HttpGet("GetCategory/{id}")]
        public async Task<IActionResult> Get([FromRoute] string id)
        {
            if (string.IsNullOrWhiteSpace(id))
            {
                return BadRequest("Category ID cannot be null or empty.");
            }

            try
            {
                var category = await _categoryRepository.GetCategoryById(id);
                if (category != null)
                {
                    return Ok(category);
                }
                return NotFound($"Category with ID '{id}' not found.");
            }
            catch (Exception ex)
            {
                // Log the exception (logging not implemented here)
                return StatusCode(500, "An error occurred while retrieving the category.");
            }
        }

        /// <summary>
        /// Adds a new category.
        /// </summary>
        /// <param name="category">The category to add.</param>
        /// <returns>An IActionResult indicating the result of the operation.</returns>
        [HttpPost("AddCategory")]
        public async Task<IActionResult> Add([FromBody] Category category)
        {
            if (category == null)
            {
                return BadRequest("Category cannot be null.");
            }

            try
            {
                await _categoryRepository.AddCategory(category);
                return CreatedAtAction(nameof(Get), new { id = category.CategoryId }, category);
            }
            catch (Exception ex)
            {
                // Log the exception (logging not implemented here)
                return StatusCode(500, "An error occurred while adding the category.");
            }
        }

        /// <summary>
        /// Updates an existing category.
        /// </summary>
        /// <param name="category">The category to update.</param>
        /// <returns>An IActionResult indicating the result of the operation.</returns>
        [HttpPut("EditCategory")]
        public async Task<IActionResult> Edit([FromBody] Category category)
        {
            if (category == null)
            {
                return BadRequest("Category cannot be null.");
            }

            try
            {
                await _categoryRepository.UpdateCategory(category);
                return Ok(category);
            }
            catch (Exception ex)
            {
                // Log the exception (logging not implemented here)
                return StatusCode(500, "An error occurred while updating the category.");
            }
        }

        /// <summary>
        /// Deletes a category by its ID.
        /// </summary>
        /// <param name="id">The ID of the category to delete.</param>
        /// <returns>An IActionResult indicating the result of the operation.</returns>
        [HttpDelete("DeleteCategory")]
        public async Task<IActionResult> Delete([FromQuery] string id)
        {
            if (string.IsNullOrWhiteSpace(id))
            {
                return BadRequest("Category ID cannot be null or empty.");
            }

            try
            {
                await _categoryRepository.DeleteCategory(id);
                return NoContent();
            }
            catch (Exception ex)
            {
                // Log the exception (logging not implemented here)
                return StatusCode(500, "An error occurred while deleting the category.");
            }
        }
    }
}

