﻿using JeansAppAPI.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace JeansAppAPI.Repository
{
    public class CategoryRepository : ICategoryRepository
    {
        private readonly JeansStationDBContext _context;
        // Constructor to inject the DbContext dependency
        public CategoryRepository(JeansStationDBContext context)
        {
            // Check if the provided context argument is null.
            // If it is null, throw an ArgumentNullException with the parameter name 'context'.
            // This ensures that the controller cannot be instantiated without a valid repository.
            _context = context ?? throw new ArgumentNullException(nameof(context));

        }

        /// <summary>
        /// Retrieves all categories from the database.
        /// </summary>
        /// <returns>A task that represents the asynchronous operation. The task result contains a list of categories.</returns>
        public async Task<List<Category>> GetAllCategories()
        {
            try
            {
                return await _context.Categories.ToListAsync();
            }
            catch (Exception ex)
            {
                // Log the exception (logging not implemented here)
                throw new InvalidOperationException("An error occurred while retrieving categories.", ex);
            }
        }

        /// <summary>
        /// Retrieves a category by its ID.
        /// </summary>
        /// <param name="id">The ID of the category to retrieve.</param>
        /// <returns>A task that represents the asynchronous operation. The task result contains the category with the specified ID.</returns>
        public async Task<Category> GetCategoryById(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
            {
                throw new ArgumentException("Category ID cannot be null or empty.", nameof(id));
            }

            try
            {
                var category = await _context.Categories.FindAsync(id);
                if (category == null)
                {
                    throw new KeyNotFoundException($"Category with ID '{id}' not found.");
                }

                return category;
            }
            catch (Exception ex)
            {
                // Log the exception (logging not implemented here)
                throw new InvalidOperationException("An error occurred while retrieving the category.", ex);
            }
        }

        /// <summary>
        /// Deletes a category by its ID.
        /// </summary>
        /// <param name="id">The ID of the category to delete.</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        public async Task DeleteCategory(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
            {
                throw new ArgumentException("Category ID cannot be null or empty.", nameof(id));
            }

            try
            {
                var category = await _context.Categories.FindAsync(id);
                if (category == null)
                {
                    throw new KeyNotFoundException($"Category with ID '{id}' not found.");
                }

                _context.Categories.Remove(category);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Log the exception (logging not implemented here)
                throw new InvalidOperationException("An error occurred while deleting the category.", ex);
            }
        }

        /// <summary>
        /// Updates an existing category.
        /// </summary>
        /// <param name="category">The category to update.</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        public async Task UpdateCategory(Category category)
        {
            if (category == null)
            {
                throw new ArgumentNullException(nameof(category), "Category cannot be null.");
            }

            try
            {
                _context.Categories.Update(category);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Log the exception (logging not implemented here)
                throw new InvalidOperationException("An error occurred while updating the category.", ex);
            }
        }

        /// <summary>
        /// Adds a new category to the database.
        /// </summary>
        /// <param name="category">The category to add.</param>
        /// <returns>A task that represents the asynchronous operation.</returns>
        public async Task AddCategory(Category category)
        {
            if (category == null)
            {
                throw new ArgumentNullException(nameof(category), "Category cannot be null.");
            }

            try
            {
                await _context.Categories.AddAsync(category);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                // Log the exception (logging not implemented here)
                throw new InvalidOperationException("An error occurred while adding the category.", ex);
            }
        }
    }
}

