﻿using JeansAppAPI.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace JeansAppAPI.Repository
{
    public interface ICategoryRepository
    {
        Task<List<Category>> GetAllCategories();
        Task<Category> GetCategoryById(string id);
        Task DeleteCategory(string id);
        Task UpdateCategory(Category category);
        Task AddCategory(Category category);
    }
}

