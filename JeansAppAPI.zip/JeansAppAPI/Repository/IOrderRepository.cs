﻿//using JeansAppAPI.Entities;

//namespace JeansAppAPI.Repository
//{
//    public interface IOrderRepository
//    {
//        void Add(Order order);
//        Order GetOrderById(Guid orderId);
//        List<Order> GetAllOrders();
//        void Delete(Guid id);
//    }
//}
