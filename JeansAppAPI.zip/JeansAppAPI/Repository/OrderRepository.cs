﻿//using JeansAppAPI.Entities;
//using Microsoft.CodeAnalysis;

//namespace JeansAppAPI.Repository
//{
//    public class OrderRepository:IOrderRepository
//    {
//        private readonly JeansStationDBContext _dbContext;

//        public OrderRepository(JeansStationDBContext dbContext)
//        {
//            _dbContext = dbContext;
//        }

//        public void Add(Order order)
//        {
//            _dbContext.Orders.Add(order);
//            _dbContext.SaveChanges();
//        }

//        public void Delete(Guid id)
//        {
//            var order = _dbContext.Orders.FirstOrDefault(x => x.OrderId== id);


//            _dbContext.Orders.Remove(order);
//            _dbContext.SaveChanges();
//        }

//        public List<Order> GetAllOrders()
//        {
//            return _dbContext.Orders.ToList();
//        }

//        public Order GetOrderById(Guid orderId)
//        {
//            var order = _dbContext.Orders.Find(orderId);
//            return order;
//        }
//    }
//}
